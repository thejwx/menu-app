import React, {Component} from 'react';
import Button from 'react-bootstrap/Button'
import Meal from './Meal'
import axios from 'axios'

export default class Meals extends Component {

  constructor(props) {
    super(props)
    this.state = {
        mealsList: [],
        days: [['Monday'],['Tuesday'],['Wednesday'],['Thursday'],['Friday'],['Saturday'],['Sunday']],
        mainIngredients: ['Poultry','Beef','Pork','Fish','Other Seafood','Carb','Vegetable'],
        styles: ['Italian','French','Asian','Latin','Mediterranean','Grilled','Crockpot','Smoked','Baked','Soup'],
        value: '',
    }
  }

  //function which is called the first time the component loads
  componentDidMount() {
    this.getMealsData();
  }

  //Function to get the Customer Data from json
  getMealsData() {
      var mealsList = [];
        this.state.days.map(day=>{
            day.push(this.pickOne(this.state.mainIngredients));
            day.push(this.pickOne(this.state.styles));
        });
      
      axios.get('./assets/samplejson/mealsList.json').then(response => {
          mealsList = response.data;
        
          mealsList.map((mealsdetail, index)=>{
              this.state.days.map(day => 
                {
                    if(day[1]===mealsdetail.mainIngredient && day[2]===mealsdetail.style){
                        day[3]=this.pickMeal(mealsdetail.meals);
                        day[4]=mealsdetail.meals;
                    }
                }
              )
            })
            this.setState({ mealsList: mealsList })
      })
      .catch(error => {
        console.log(error);
        });
  }
    
    pickOne(arr){
        const index = Math.floor(Math.random() * arr.length);
        const item = arr[index];
        arr.splice(index,1);
        return item;
    }

    pickMeal(meals) {
        const mealIndex = Math.floor((Math.random() * meals.length));
        return meals[mealIndex];
    }
    
    myCallback = (index) => {
        const currentMeal = this.state.days[index][3];
        const currentMeals = this.state.days[index][4];
        const newMeal = this.pickMeal(currentMeals);
        const newDays = this.state.days;
        if(currentMeals.length<=1){
            alert('There is only one meal for this ingredient and styla pair.');
        } else if(currentMeal!=newMeal){
            newDays[index][3] = newMeal;
            this.setState({days: newDays});
        } else {
            this.myCallback(index,currentMeals);
        }
    }

    render() {
      return (
          <div>
          {this.state.days.map((day, index) =>
            <Meal key={index} index={index} day={day[0]} mainIngredient={day[1]} style={day[2]} meal={day[3]} callback={this.myCallback}/>
          )}
          </div>
      )
    }

}

