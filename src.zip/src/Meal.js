import React, {Component} from 'react';
import './meal.css';

//This Component is a child Component of Customers Component
export default class SomeText extends Component {

  constructor(props) {
    super(props);
    this.state = {index: 0};
  }

  render() {
    return (
    <div class="dailyRecord">
        <div class="day">
            {this.props.day}
        </div>
        <div class="style">
            ({this.props.mainIngredient}, {this.props.style})
        </div>
        <div><RefreshForm index={this.props.index} callback={this.props.callback} /></div>
        <div class="meal">
            <a href={'https://www.pinterest.com/search/pins/?q='+this.props.meal+' '+this.props.style} target='_blank'>{this.props.meal}</a>
        </div>
    </div>)
  }
}

class RefreshForm extends React.Component {
  constructor(props) {
    super(props);

    this.state = {value: ''};
    this.handleSubmit = this.handleSubmit.bind(this);
  }

  handleSubmit(event) {
    this.props.callback(this.props.index);
    event.preventDefault();
  }

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <input className='refreshImage' type='image' src='./assets/images/512px-Repeat_font_awesome.svg.png' value='Replace Meal' />
      </form>
    );
  }
}
